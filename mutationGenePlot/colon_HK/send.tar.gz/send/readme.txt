Region[1]: 左边第一块：Responsible for down-regulation through a process mediated by direct ubiquitination
	   左边第二块：Highly charged

Motif[2]: 左边第一块：Microtubule tip localization signal
	  左边第二块：PDZ-binding

Motif只有几个aa，因此这两块放大了（5倍）。

参考：UniProtKB (http://www.uniprot.org/uniprot/P25054)
